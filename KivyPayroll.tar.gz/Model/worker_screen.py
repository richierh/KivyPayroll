from Model.base_model import BaseScreenModel


class WorkerScreenModel(BaseScreenModel):
    """
    Implements the logic of the
    :class:`~View.worker_screen.WorkerScreen.WorkerScreenView` class.
    """