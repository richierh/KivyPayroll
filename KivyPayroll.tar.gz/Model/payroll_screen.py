from Model.base_model import BaseScreenModel


class PayrollScreenModel(BaseScreenModel):
    """
    Implements the logic of the
    :class:`~View.payroll_screen.PayrollScreen.PayrollScreenView` class.
    """