# This directory is for common responsive design components
