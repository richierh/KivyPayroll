from kivymd.uix.screen import MDScreen


class DesktopScreenView(MDScreen):
    pass
