from kivymd.uix.screen import MDScreen


class TabletScreenView(MDScreen):
    pass
