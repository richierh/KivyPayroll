from .platforms.MobileScreen.mobile_screen import MobileScreenView
from .platforms.TabletScreen.tablet_screen import TabletScreenView
from .platforms.DesktopScreen.desktop_screen import DesktopScreenView
